# %%
# Import neccessary libraries
import pandas as pd
import json, psycopg2, sqlalchemy, warnings
from datetime import datetime
import pytz

warnings.filterwarnings("ignore")

# %%
# Function for executing SQL command on PostgreSQL database
def exec_query_on_psql(database_url: str, sql_query: str) -> None:
    # Connect to the PostgreSQL database
    conn = psycopg2.connect(database_url)

    # Set autocommit to True
    conn.autocommit = True

    # Create a cursor object
    cur = conn.cursor()

    try:
        # Execute the SQL query
        cur.execute(sql_query)
        # print("Query executed successfully.")
    except psycopg2.Error as e:
        print(f"Error executing query: {e}")
    finally:
        # Close the cursor and connection
        cur.close()
        conn.close()

# %%
# Function for creating a database if it doesn't exist
def create_database_if_not_exists(database_url: str, new_dbname: str) -> None:
    # Connect to the PostgreSQL server
    conn = psycopg2.connect(database_url)
    
    # Set autocommit to True
    conn.autocommit = True
    
    # Create a cursor object
    cur = conn.cursor()
    
    try:
        # Check if the database already exists
        cur.execute(f"SELECT 1 FROM pg_database WHERE datname = '{new_dbname}';")
        if cur.fetchone():
            print(f"Database '{new_dbname}' already exists.")
        else:
            # Create the database
            create_db_query = f"CREATE DATABASE {new_dbname};"
            cur.execute(create_db_query)
            print(f"Database '{new_dbname}' created successfully.")
    except psycopg2.Error as e:
        print(f"Error executing query: {e}")
    finally:
        # Close the cursor and connection
        cur.close()
        conn.close()

# %%
# Function for loading source file into pandas dataframe
def load_source_data(customer_txn_file_nm: str, product_file_nm: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    try:
        with open(customer_txn_file_nm) as f:
            customer_txn = json.load(f)
        df_customer_txn = pd.DataFrame(customer_txn)
        df_product_catalog = pd.read_csv(product_file_nm)
        print("Successfully load new source files into Pandas DataFrame")
        return df_customer_txn, df_product_catalog
    except Exception as e:
        raise Exception(f"Cannot load source files: {e}")

# %%
# Function for cleaning and transforming product_catalog dataframe
def transform_product(product_df: pd.DataFrame) -> pd.DataFrame:
    # Convert price to numeric, invalid parsing will be set as NaN
    product_df['price'] = pd.to_numeric(product_df['price'], errors='coerce')
    # Drop duplicate and NaN value 
    transform_product_df = product_df.dropna(inplace=False).drop_duplicates()
    # Remove rows that contain negative values in the price column
    transform_product_df = transform_product_df[(transform_product_df['price'] >= 0)]
    # Sort by product_id in ascending order
    transform_product_df = transform_product_df.sort_values(by='product_id', ascending=True)
    return transform_product_df

# %%
# Function for cleaning and transforming customer_transaction dataframe
def transform_customer_txn(customer_txn_df: pd.DataFrame) -> pd.DataFrame:
    # Convert timestamp column to datetime
    customer_txn_df['timestamp'] = pd.to_datetime(customer_txn_df['timestamp'], errors='coerce')
    # Drop duplicate
    transform_customer_txn_df = customer_txn_df.dropna(inplace=False).drop_duplicates()
    return transform_customer_txn_df

# %%
# Function for creating unified dataset (merge product_catalog and customer_transaction)
def create_unified_dataset(product_df: pd.DataFrame, customer_txn_df: pd.DataFrame) -> pd.DataFrame:
    customer_txn_selected = customer_txn_df
    product_selected = product_df[['product_id', 'product_name', 'category']]
    # Merge two source dataframes
    merged_df = pd.merge(customer_txn_selected, product_selected, how='left', left_on='product_id', right_on='product_id')
    # Rename columns
    merged_df.rename(columns={"price":"price_per_unit", "timestamp":"transaction_datetime"}, inplace=True)
    # Add 'TOTAL_PRICE' column to merged dataframe
    merged_df['total_price'] = merged_df['quantity'] * merged_df['price_per_unit']
    # Add 'CREATE_DATETIME' column to merged dataframe
    timezone = pytz.timezone('Asia/Bangkok')  # GMT+7
    merged_df['create_datetime'] = datetime.now(timezone).replace(microsecond=0)
    # Reorder columns in merged dataframe
    col_order = ['transaction_id', 'customer_id', 'product_id', 'product_name', 'category', 'quantity', 'price_per_unit', 'total_price', 'transaction_datetime', 'create_datetime']
    merged_df = merged_df[col_order]
    print("Done merging customer transaction and product catalog dataframes")
    return merged_df

# %%
# Function for creating PostgresSQL database engine
def create_psql_engine(database_url: str) -> sqlalchemy.engine.base.Engine:
    engine = sqlalchemy.create_engine(database_url)
    return engine

# %%
# Function for storing new transaction data in target table
def store_data(source_df: pd.DataFrame, tgt_tbl: str, engine: sqlalchemy.engine.base.Engine, database_url: str) -> None:
    # Create a temporary table to hold the new ingested data
    source_df.to_sql('temp_new_customer_transaction', engine, if_exists='replace', index=False)
    print("Temporary table 'temp_new_customer_transaction' has been created.")

    # Load source data into target table in PostgreSQL database (performing 'upsert' load type)
    upsert_query = f"""
    INSERT INTO {tgt_tbl} 
    (transaction_id, customer_id, product_id, product_name, category, quantity, price_per_unit, total_price, transaction_datetime, create_datetime)
    SELECT transaction_id, customer_id, product_id, product_name, category, quantity, price_per_unit, total_price, transaction_datetime, create_datetime
    FROM temp_new_customer_transaction
    ON CONFLICT (transaction_id) DO UPDATE SET
    customer_id = EXCLUDED.customer_id,
    product_id = EXCLUDED.product_id,
    product_name = EXCLUDED.product_name,
    category = EXCLUDED.category,
    quantity = EXCLUDED.quantity,
    price_per_unit = EXCLUDED.price_per_unit,
    total_price = EXCLUDED.total_price,
    transaction_datetime = EXCLUDED.transaction_datetime,
    create_datetime = EXCLUDED.create_datetime
    ;
    """
    try:
        exec_query_on_psql(database_url, upsert_query)
        print("Successfully load new transaction data into customer transaction table.")
    except Exception as e:
        print(f"Error executing query: {e}")

    # Drop temp table
    drop_temp_query = "DROP TABLE temp_new_customer_transaction;"
    try:
        exec_query_on_psql(database_url, drop_temp_query)
        print("Temporary table 'temp_new_customer_transaction' has been dropped successfully.")
    except Exception as e:
        print(f"Error executing query: {e}")

# %%
def main(
    customer_txn_file_nm: str,
    product_file_nm: str
) -> None:
    database_url = "postgres://zrch:1234@db:5432/shopsmart"
    database_url_psycopg2 = "postgresql+psycopg2://zrch:1234@db:5432/shopsmart"
    print(f"DATABASE_URL : {database_url}")
    print(f"Source file name : '{customer_txn_file_nm}' and '{product_file_nm}'")

    # Create 'shopsmart' database on PostgreSQL database
    # create_database_if_not_exists(database_url, new_dbname)

    # Create unified target table on PostgresSQL database
    create_tbl_query = """
        CREATE TABLE IF NOT EXISTS customer_transaction (
              transaction_id 	        VARCHAR	PRIMARY KEY	
            , customer_id 		        VARCHAR
            , product_id		        VARCHAR
            , product_name		        VARCHAR
            , category			        VARCHAR
            , quantity			        INT
            , price_per_unit	        FLOAT
            , total_price               FLOAT
            , transaction_datetime		TIMESTAMP
            , create_datetime           TIMESTAMP
        );
    """
    exec_query_on_psql(database_url, create_tbl_query)
    df_customer_txn, df_product_catalog = load_source_data(customer_txn_file_nm, product_file_nm)

    # Transform product catalog dataframe
    transform_product_df = transform_product(df_product_catalog)
    # Transform customer transaction dataframe
    transform_customer_txn_df = transform_customer_txn(df_customer_txn)
    # Create psql engine
    engine = create_psql_engine(database_url_psycopg2)
    # Create a unified source dataset
    unified_dataset = create_unified_dataset(transform_product_df, transform_customer_txn_df)
    # Store processed data in PostgreSQL database
    store_data(unified_dataset, 'customer_transaction', engine, database_url)

# %%
cust_txn_file = 'customer_transactions.json'
product_file = 'product_catalog.csv'
if __name__ == "__main__":
    main(cust_txn_file, product_file)